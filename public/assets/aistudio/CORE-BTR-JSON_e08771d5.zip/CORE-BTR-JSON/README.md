# CORE BTR JSON export

## Contents
- `manifest.json`: dataset inventory and counts.
- `qbank/index.json`: master index of Qbank topic sets.
- `qbank/<subject>/index.json`: subject-level topic index.
- `qbank/<subject>/<set-id>.json`: complete topic set and its questions.
- `tests/index.json`: master index of non-Qbank test sets.
- `tests/<test-category>/<set-id>.json`: complete test set and its questions.
- `schemas/`: JSON Schema definitions.
- `validation-report.json`: extraction counts, duplicate IDs and warnings.

## Data preservation
Question objects are preserved in the source's field structure. Set metadata is normalized to readable names such as `duration_minutes` and `num_questions_extracted`; the original declared question count remains available as `num_questions_source`. Media URLs are references only.

## Important
The original HTML is not included in this ZIP. Keep your source HTML as a backup. See `validation-report.json` before using the dataset in production.
